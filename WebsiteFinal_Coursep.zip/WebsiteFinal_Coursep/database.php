<?php

     $con = mysqli_connect('localhost','root','','admin') or die("<h1>Connection failed...</h1>");

     function loginUser($array)
     {
         global $con;
         $email = $array['email'];
         $passcode = $array['passcode'];
         
         $query = "select * from details where email = '$email' and passcode = '$passcode'";
         $result = mysqli_query($con,$query);
         $res = mysqli_fetch_array($result);
         return $res;
         
     }

     function getUser($email)
	{
		global $con;
		$query = "select * from details where email = '$email'";
		$rs1 = mysqli_query($con,$query);
		$result = mysqli_fetch_array($rs1);

		return $result;
	}

    function updateUser($array)
	{
		global $con;
		$fname = $array['fname'];
        $lname = $array['lname'];
		$email = $array['email'];
		$phnumber = $array['phnumber'];
		$passcode = $array['passcode'];
		$cpasscode = $array['cpasscode'];
	 
    	$query = "update details set fname='$fname',lname='$lname',phnumber = '$phnumber',passcode='$passcode',cpasscode='$cpasscode' where email = '$email'";
		mysqli_query($con,$query);  
		$res = mysqli_affected_rows($con);  //1 : success ,0 data not insert and -1 query error
		
        return $res; 		
		 
	}

    function deleteUser($email)
	{
		global $con;
		$query = "delete from donate_details where email = '$email'";
		mysqli_query($con,$query);
		$rs = mysqli_affected_rows($con);
        $query2 = "delete from details where email = '$email'";
        mysqli_query($con,$query);
        $rs2 = mysqli_affected_rows($con);
	    return $rs2;
	}
?>