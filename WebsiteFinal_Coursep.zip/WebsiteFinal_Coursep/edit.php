<?php
   include('database.php');
   session_start();
   $res = updateUser($_GET);
   if($res>0)
   {
	   //echo "Success ....$res";
       header('location:admincontrol.php');
   }
   else
   {
	 echo "Failed.. $res";
     // header('location:error.php');
   }
?>