<?php

   session_start();
   include('database.php');
   $email = $_GET['email'];  //id : key and $id : variable
   $std = getUser($email);

?>

<html>
  <head>
    <title>Insert data</title>

    <script>
      function init()
      {
        fnam = document.getElementById()
        lnam = document.getElementById('lname');
	    mobile = document.getElementById('phnumber');
        password = document.getElementById('passcode');
	    cpassword = document.getElementById('cpasscode');


        err1 = document.getElementById('err1');
	    err2 = document.getElementById('err2');
	    err3 = document.getElementById('err3');
        err4 = document.getElementById('err4');
        err5 = document.getElementById('err5');
      }
      function validation()
      {
        var fnm = fnam.value;
        var lnm = lnam.value;
	    var mob = mobile.value;
        var pass = password.value;
	    var cpass = cpassword.value;


        if(fnm.length == 0)
	      {
	        err1.innerHTML = "Plz Enter First Name..";
		      err1.style.color="red";
	      }	 
	      else
	      {
	        err1.innerHTML = "";
	      }

        if(lnm.length == 0)
	      {
	        err2.innerHTML = "Plz Enter last Name..";
		      err2.style.color="red";
	      }	 
	      else
	      {
	        err2.innerHTML = "";
	      }

        if(mob.length == 0)
	      {
	        err3.innerHTML = "Plz Enter Mobile..";
	        err3.style.color = "red";
	      }
	      else if(isNaN(mob))   //isNaN() : It is pre-define function : not a number
	      {
	        err3.innerHTML = "Plz enter only digits.";
		      err3.style.color = "red";
	      }
	      else if(mob.length<10 || mob.length>10)
	      {
	        err3.innerHTML = "Plz enter 10 digit number";
		      err3.style.color="red";
	      }
	      else
	      {
	        err3.innerHTML = "";
	      }
        if(pass.length == 0)
        {
	        err4.innerHTML = "Plz Enter Password..";
		      err4.style.color="red";
	      } 
	      else if(pass.length<5 || pass.length>8)
	      {
	        err4.innerHTML = "password length must be 5 to 8 char";
		      err4.style.color="red";
	      }
	      else
	      {
	        err4.innerHTML = ""; 
	      }
          if(cpass.length == 0)
        {
	        err5.innerHTML = "Plz Re-Enter Password..";
		      err5.style.color="red";
	      } 
	      else
	      {
	        err5.innerHTML = "";
	      }
      }

      function checkpass()
      {

        if(cpassword.value != password.value)
	      {
	        err5.innerHTML = "Password not match..";
		      err5.style.color="red";
	      }
	      else
	      {
	        err5.innerHTML = "";
	      }

            
      }
    </script>

  </head>
  <body onload="init()">
   <center>
   <form action="edit.php" method="get">
	   <input type="text" value="<?php echo $std['email'];?>" name="email" readonly><br><br> 
	   <input type="text" value="<?php echo $std['fname'];?>" id="fname" name="fname" onblur="validation()"><br><br>
     <span id="err1"></span>
	   <input type="text" value="<?php echo $std['lname'];?>" id="lname" name="lname" onkeyup="validation()"><br><br>
     <span id="err2"></span>
	   <input type="text" value="<?php echo $std['phnumber'];?>" id="phnumber" name="phnumber" onkeyup="validation()"><br><br>
     <span id="err3"></span>
	   <input type="text" value="<?php echo $std['passcode'];?>" id="passcode" name="passcode" onkeyup="validation()"><br><br>
     <span id="err4"></span>
     <input type="text" value="<?php echo $std['cpasscode'];?>" id="cpasscode" name="cpasscode" onkeyup="checkpass()"><br><br>
     <span id="err5"></span>

	   <input type="submit" value="Submit Data" onclick="validation()"><br><br>
	 </form>
   </center>
  </body>
</html>