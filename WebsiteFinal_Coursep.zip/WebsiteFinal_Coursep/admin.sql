-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 31, 2021 at 06:50 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `fname` varchar(15) NOT NULL,
  `lname` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phnumber` bigint(10) NOT NULL,
  `passcode` varchar(40) NOT NULL,
  `cpasscode` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`fname`, `lname`, `email`, `phnumber`, `passcode`, `cpasscode`) VALUES
('Agammmm', 'Jain', 'Agam.Jain@gmail.com', 9981565698, 'aga123', 'aga123'),
('Atharvaaa', 'Puranik', 'atharva.puranik@gmail.com', 9898058581, 'ath123', 'ath123'),
('Kunal', 'ojha', 'kunal.ojha@gmail.com', 9988156569, '09876543', '09876543'),
('priyanshi', 'mulgaonkar', 'priyan.shi@gmail.com', 1234545678, 'priya123', 'priya123'),
('puru', 'chauhan', 'puru.chauhan@gmail.com', 957576045, '12345678', '12345678'),
('rudresh', 'sharma', 'rudresh.sharma@gmail.com', 7987534331, 'rud123', 'rud123'),
('satvik', 'gupta', 'satvik.gupta@gmail.com', 9899256788, 'sat123', 'sat124'),
('Sakshi', 'harbhajanka', 'sc@gmail.com', 9898745456, 'sc123', 'sc123'),
('Dharmesh ', 'jariwala', 'sj@gmail.com', 1234567890, '1234567', '1234567'),
('Vidushi', 'Yadav', 'vidushi.yadav@gmail.com', 9898067675, '112233', '112233'),
('vishwi', 'ghanekar', 'vishwi.ghanekar@gmail.com', 5689902345, 'vish123', 'vish123');

-- --------------------------------------------------------

--
-- Table structure for table `donate_details`
--

CREATE TABLE `donate_details` (
  `donateid` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `foodtype` varchar(30) NOT NULL,
  `food_description` varchar(100) NOT NULL,
  `foodamnt` varchar(50) NOT NULL,
  `ptime` varchar(20) NOT NULL,
  `pincode` int(7) NOT NULL,
  `address` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donate_details`
--

INSERT INTO `donate_details` (`donateid`, `email`, `foodtype`, `food_description`, `foodamnt`, `ptime`, `pincode`, `address`) VALUES
(2, 'vidushi.yadav@gmail.com', 'veg', 'Pizza', '12 kh', '12:45', 234567, 'djhdfgh'),
(3, 'puru.chauhan@gmail.com', 'non-veg', 'pav bhaji edible', '5 person ', '05:06', 456001, '101, Sethi Nagar , Ujjain \r\n'),
(7, 'rudresh.sharma@gmail.com', 'veg', 'fresh and edible food', '3 per head', '07:02', 456010, '198, Shivaji Park colony Ujjain'),
(12, 'vidushi.yadav@gmail.com', 'veg', 'Home made food. ', '7 chapattis ,  2 vegetables', '20:02', 457001, '32, vedvyas colony  Ratlam'),
(13, 'Agam.Jain@gmail.com', 'non-veg', 'Tikka and juice ', '4 person per head ', '16:00', 457001, '90 Gulmarg residency Ratlam'),
(14, 'vishwi.ghanekar@gmail.com', 'veg', 'plant based meat', '50kg', '02:35', 999, 'Amritsar'),
(15, 'satvik.gupta@gmail.com', 'veg', 'fresh  food, edible ', '2 person per head', '02:06', 456001, 'xyz\r\nUjjain'),
(16, 'vidushi.yadav@gmail.com', 'veg', 'fresh', '50kg', '14:09', 456001, 'poi'),
(17, 'vidushi.yadav@gmail.com', 'veg', 'qwert', 'efg', '07:06', 123445, 'pdf');

-- --------------------------------------------------------

--
-- Table structure for table `fundraiser`
--

CREATE TABLE `fundraiser` (
  `name` varchar(15) NOT NULL,
  `damnt` int(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `phnumber` bigint(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pincode` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fundraiser`
--

INSERT INTO `fundraiser` (`name`, `damnt`, `country`, `phnumber`, `address`, `pincode`) VALUES
('vid', 200, 'india', 98765432, 'q', 123455),
('vidushi', 200, 'india', 1234567890, 'poi', 123456),
('ayush', 100, 'India', 9876567890, 'Gujarat', 909876),
('satvik gupta', 300, 'India', 9981565698, 'xyz street\r\nUjjain ', 456001),
('Prathamesh', 200, 'Egypt', 9998887776, '45 cairo colony, cairo road, near cairo hospital, cairo', 898765);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `phnumber` (`phnumber`);

--
-- Indexes for table `donate_details`
--
ALTER TABLE `donate_details`
  ADD PRIMARY KEY (`donateid`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `fundraiser`
--
ALTER TABLE `fundraiser`
  ADD UNIQUE KEY `phnumber` (`phnumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donate_details`
--
ALTER TABLE `donate_details`
  MODIFY `donateid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `donate_details`
--
ALTER TABLE `donate_details`
  ADD CONSTRAINT `donate_details_ibfk_1` FOREIGN KEY (`email`) REFERENCES `details` (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
