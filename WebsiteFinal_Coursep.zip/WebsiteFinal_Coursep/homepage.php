<?php

session_start();
$email = $_SESSION['email'];

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HOME</title>

        <style>
            .container{
                display: flex;
                flex-direction: row;
                justify-content: space-evenly;
                align-items: center;
                text-align: center;
                min-height: 100vh;
            }
            button{
                width: 230px;
                height: 80px;
                border: none;
                color: rgb(221, 182, 77, 100%);
                background-color: rgb(16, 64, 97, 100%);
                border-radius: 0px;
                box-shadow: inset 0 0 0 0 #f9e506;
                transition: ease-out 0.3s;
                font-size: 2rem;
                outline: none

            }
            button:hover{
                box-shadow: inset 230px 0 0 0 #f9e506;
                cursor: pointer;
                color: black;

            }
            body{
                margin: 0;
                padding: 0;
                background: whitesmoke;
            }
            ul{
                /*width: 100%;*/ padding: 0;
                margin: 0 0 0 500px;
                list-style: none;
                width: 100%;
            }
            li{
                float: left;
            }
            li a{
                width: 100px;
                display: inline-block;
                padding: 45px 30px;
                text-decoration: solid;
                font-family: Arial, Helvetica, sans-serif;
                color: whitesmoke;
                text-align: center;

            }
            li a:hover{
                background: rgb(182, 102, 36);
                text-transform: uppercase;
            }

            nav{
                width: 100%;
                height: 100px;
                overflow: auto;
                background: rgb(221, 182, 77, 100%);
            }


            .fnttxt{
                padding: 0px;
                text-align: center;
            }
            .fntstyle{
                font-family: RAMARAJA;
                color: rgb(16, 64, 97, 100%);
                font-size: 80px;
            }
            .fntstyle1{
                font-family: sans-serif;
                font-size: 30px;
            }
            .img1 {
            
            margin-left: 10%;
            display: blocks;
            width: 70%;
            /* object-fit: contain; */
            /* margin-right: 2%; */

            /* height: 10%;    */
            }

            .active1{
            background-color: burlywood;
            }
            .img2{
                border: 3px  solid black;
                padding: 15px;
                size: 30px;
                
            }
            



        </style>
    </head>
    <body>
        
        <nav>
            
            <ul>
                <li><a class="active1" href="homepage.php">Home</a></li>
                <li><a href="ourmission.html">Our Mission</a></li>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="fundraizer.html">Fund Raiser</a></li>
                <li><a href="solution.html">Solutions</a></li>
                <li><a href="donatenow.php">Donate Now</a></li>
                <li><a href="learning.html">Learning</a></li>
                <li><a href="contactus.html">Contact Us</a></li>
            </ul>
            
        </nav>
        <!-- <div class="img1"> -->
            <div>
            <img src="help.jpeg" style="width:1450px;height:750px;">

            </div>
        <!-- </div> -->
        <div class="fnttxt">
            <h2 class="fntstyle">#अन्नPURNA</h2>
            <i><h3>CHARITY BEGINS FROM HOME</h3></i>
        </div>
        <div>
            <img class="img2" src="home1.jpeg">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<button onclick="document.location= 'donatenow.php'" class="button">DONATE</button>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<img class="img2" src="home2.jpeg">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<button class="button" onclick= "document.location='logout.php'" >LOGOUT</button>


    </body>
</html>


