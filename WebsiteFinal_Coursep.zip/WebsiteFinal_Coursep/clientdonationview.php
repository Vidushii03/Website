<?php
include('database.php');
session_start();
$email = $_SESSION['email'];

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Client Donation View</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>

            body{
                margin: 0;
                padding: 0;
                background: whitesmoke;
            }
            ul{
                /*width: 100%;*/ padding: 0;
                margin: 0 0 0 500px;
                list-style: none;
                width: 100%;
                
            }
            li{
                float: left;
            }
            li a{
                width: 100px;
                display: inline-block;
                padding: 45px 30px;
                text-decoration: solid;
                font-family: Arial, Helvetica, sans-serif;
                color: whitesmoke;
                text-align: center;

            }
            li a:hover{
                background: rgb(182, 102, 36);
                text-transform: uppercase;
            }

            nav{
                width: 100%;
                height: 100px;
                overflow: auto;
                background: rgb(206, 179, 60);
            }


            .fnttxt{
                padding: 70px;
                text-align: center;
            }
            .fntstyle{
                font-family: cursive;
                color: rgb(212, 177, 212);
                font-size: 60px;
            }
            .fntstyle1{
                font-family: sans-serif;
                font-size: 30px;
            }
            .img1 {
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 50%;
            
        }
        .active1{
            background-color: burlywood;
        }

        </style>
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="homepage.php">Home</a></li>
                <li><a href="ourmission.html">Our Mission</a></li>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="fundraizer.html">Fund Raiser</a></li>
                <li><a href="solution.html">Solutions</a></li>
                <li><a class="active1" href="donatenow.php">Donate Now</a></li>
                <li><a href="learning.html">Learning</a></li>
                <li><a href="contactus.html">Contact Us</a></li>
            </ul>
        </nav>

        <div>
            <h1>Donation History</h1><br><br>


            <table border="2px" cellspacing="8px" cellpadding="10px"> 

                <tr>

                    <th>S.No.</th>
                    <th>Email</th>
                    <th>Food Type</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Pickup Time</th>
                    <th>Address</th>
                    <th>Pincode</th>
                </tr>

                <?php
                $query="select * from donate_details where email='$email'";
                $result=mysqli_query($con,$query);
                $i=1;
                while($res = mysqli_fetch_array($result))
                {
                $email = $_SESSION['email'];
                $foodtype = $res['foodtype'];
                $food_description = $res['food_description'];
                $foodamnt = $res['foodamnt'];
                $ptime = $res['ptime'];
                $address = $res['address'];
                $pincode = $res['pincode'];

                ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $email; ?></td>
                    <td><?php echo $foodtype; ?></td>
                    <td><?php echo $food_description; ?></td>
                    <td><?php echo $foodamnt; ?></td>
                    <td><?php echo $ptime; ?></td>
                    <td><?php echo $address; ?></td>
                    <td><?php echo $pincode; ?></td>
                </tr>

                <?php	
                $i++;}
                ?>
            </table>
        </div>

    </body>
</html>