<?php
  
   include('database.php');
   $email = $_GET['email'];
   
   $result = deleteUser($email);   
   if($result>0)
   {
	  // echo "<h1>Data Successfully delete....$result</h1>";
      header('location:admincontrol.php');
   }
   else
   {
	   echo "<h1>Data Not Deleted.....$result</h1>";
   }
?>