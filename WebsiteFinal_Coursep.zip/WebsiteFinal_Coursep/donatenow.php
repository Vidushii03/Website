<?php

session_start();
$email = $_SESSION['email'];

?>

<!DOCTYPE html>
<html>
    <head>
        <title>DONATE NOW</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>

            body{
                margin: 0;
                padding: 0;
                background: whitesmoke;
                /*background: url('https://i.imgur.com/kk76J5I.jpg') no-repeat top center;*/
                /*background-size: cover;*/
                /*height: 100vh;*/
            }
            ul{
                /*width: 100%;*/ padding: 0;
                margin: 0 0 0 500px;
                list-style: none;
                width: 100%;
                
            }
            li{
                float: left;
            }
            li a{
                width: 100px;
                display: inline-block;
                padding: 45px 30px;
                text-decoration: solid;
                font-family: Arial, Helvetica, sans-serif;
                color: whitesmoke;
                text-align: center;

            }
            li a:hover{
                background: rgb(182, 102, 36);
                text-transform: uppercase;
            }

            nav{
                width: 100%;
                height: 100px;
                overflow: auto;
                background: rgb(206, 179, 60);
            }


            .fnttxt{
                padding: 70px;
                text-align: center;
            }
            .fntstyle{
                font-family: cursive;
                color: rgb(212, 177, 212);
                font-size: 60px;
            }
            .fntstyle1{
                font-family: sans-serif;
                font-size: 30px;
            }
            .img1 {
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 50%;
           
            
        }
        @import url('https://fonts.googleapis.com/css?family=Roboto');

        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        outline: none;
        font-family: 'Roboto', sans-serif;
        }



        .wrapper{
        position: absolute;
        top: 60%;
        left: 20%;
        transform: translate(-50%, -50%);
        width: 100%;
        max-width: 550px;
        background: rgb(201, 204, 205, 100%);
        padding: 30px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(247, 243, 243, 0.3);
        }

        .wrapper .title h1{
        color: rgb(221, 182,77, 100%);
        text-align: center;
        margin-bottom: 25px;
        }

        .reqforfoodform{
        display: flex;
        }

        .input-fields{
        display: flex;
        flex-direction: column;
        margin-right: 4%;
        }

        .input-fields,
        .msg{
        width: 48%;
        }

        .input-fields .input,
        .msg textarea{
        margin: 10px 0;
        background: transparent;
        border: 0px;
        border-bottom: 2px solid rgb(148, 84, 20, 100%);
        padding: 10px;
        color: rgb(148, 84, 20, 100%);
        width: 100%;
        }

        .msg textarea{
        height: 212px;
        }

        ::-webkit-input-placeholder {
        /* Chrome/Opera/Safari */
        color: rgb(148, 84, 20, 100%);
        }
        ::-moz-placeholder {
        /* Firefox 19+ */
        color: rgb(148, 84, 20, 100%);
        }
        :-ms-input-placeholder {
        /* IE 10+ */
        color: rgb(148, 84, 20, 100%);
        }

        .dbutton {
        background: rgb(90, 68, 34,100%);
        text-align: center;
        padding: 15px;
        border-radius: 5px;
        color: rgb(221, 182, 77, 100%);
        cursor: pointer;
        text-transform: uppercase;
        }

        @media screen and (max-width: 600px){
        .contact-form{
        flex-direction: column;
        }
        .msg textarea{
        height: 80px;
        }
        .input-fields,
        .msg{
        width: 100%;
    }
}
        .active1{
        background-color: burlywood;
        }
        body {
            background-image: url('reqforfood.jpeg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
        }

        </style>
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="homepage.php">Home</a></li>
                <li><a href="ourmission.html">Our Mission</a></li>
                <li><a href="aboutus.html">About Us</a></li>
                <li><a href="fundraizer.html">Fund Raiser</a></li>
                <li><a href="solution.html">Solutions</a></li>
                <li><a class="active1" href="donatenow.php">Donate Now</a></li>
                <li><a href="learning.html">Learning</a></li>
                <li><a href="contactus.html">Contact Us</a></li>
            </ul>
        </nav>

        <div class="wrapper">
            <div class="reqforfoodform">
                <div class="input-fields">
                    <form action="insert2.php" method="get">
                        <div>
                            <h1>Donate Now</h1><br>
                            <label>Please select food type</label>
                            <select name="foodtype" id="foodtype">
                                <option value="veg">VEG</option>
                                <option value="non-veg">NON-VEG</option>
                            </select>

                            <input type="text" class="input" id="food_description" name="food_description" placeholder="Food Description" required>
                            <input type="text" class="input" id="amount_food" name="amount_food" placeholder="Amount of food" required>
                            <input type="time" class="input" id="time" name="time" placeholder="Prefrerred time to collect food" required>
                            
                        </div>
                        <div class="msg">
                            <textarea name="address" id="address" placeholder="Address" required></textarea>
                            <input type="text" class="input" id="pincode" name="pincode" placeholder="Pincode" maxlength="6" required>
                            
                        </div>
                        <button type="submit" class="dbutton">DONATE NOW</button>
                    </form>

                </div>

            </div>
        </div>

    </body>
</html>