<?php
// 
include('database.php');
session_start();

$res = loginUser($_GET);

if(!empty($res))
{
$email = $res ['email'];
$passcode = $res ['passcode'];

$_SESSION['email'] = $email;
header('location:homepage.php');
}
else {
    header('location:loginpage.html');
}

?>