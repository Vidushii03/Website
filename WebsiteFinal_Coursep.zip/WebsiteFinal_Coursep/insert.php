<?php
    // get values from the sign up form with the get method

    $fname = $_GET['fname'];
    $lname = $_GET['lname'];
    $email = $_GET['email'];
    $phnumber = $_GET['phnumber'];
    $password = $_GET['passcode'];
	$cpassword = $_GET['cpasscode'];

// mysqli will connect to database 4 parameter
    $con = mysqli_connect('localhost','root','','admin') or die ("<h1>connection failed</h1>");
    if ($con)
    {
        // inserting values in the table(database)
        $query = "insert into details values('$fname', '$lname', '$email', $phnumber, '$password','$cpassword')";
        $res = mysqli_query($con, $query);

        if($res)
        {
            //echo "<h1>Data inserted...</h1>";
            header("location:loginpage.html");
        }
        else
        {
            echo "<h1>Data not inserted...</h1>";
        }
    }

?>