<?php

include('database.php');
     session_start();
     $email = $_SESSION['email'];


    $foodtype = $_GET['foodtype'];
    $food_description = $_GET['food_description'];
    $foodamnt = $_GET['amount_food'];
    
	$ptime = $_GET['time'];
    $address = $_GET['address'];
    $pincode = $_GET['pincode'];


    if ($con)
    {
        $query = "insert into donate_details (`email`,`foodtype`,`food_description`,`foodamnt`,`ptime`,`pincode`,`address`) values('$email','$foodtype','$food_description','$foodamnt','$ptime','$pincode','$address')";
        $res = mysqli_query($con, $query);

        if($res)
        {
           // echo "<h1>Data inserted...</h1>";
            header("location:clientdonationview.php");
        }
        else
        {
            echo "<h1>Data not inserted...</h1>";
        }
    }

?>