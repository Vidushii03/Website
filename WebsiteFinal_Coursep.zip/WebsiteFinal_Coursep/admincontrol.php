<?php
     
	 include('database.php');
	 $query = "select * from details"; //get all users
     $res = mysqli_query($con,$query);
?>
<html>
  <head>
    <title>Admin Control</title>
  </head>
  <body>
    <table border="2px" cellspacing="8px" cellpadding="10px"> 
	  <tr>
	    <th>S.No.</th>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Email Address</th>
		<th>Phone Number</th>
		<th>Password</th>
		<th>ACTION</th>
	  </tr>
	  <?php
      $i=1;
	    while($rs = mysqli_fetch_array($res))
		{
			$fname = $rs['fname'];   //this keys is a table coloumn name
			$lname = $rs['lname'];
			$email = $rs['email'];
			$phnumber = $rs['phnumber'];
			$passcode = $rs['passcode'];
		?>
         <tr>
           <td><?php echo $i;?></td> 
	       <td><?php echo $fname; ?></td>
		   <td><?php echo $lname; ?></td>
		   <td><?php echo $email; ?></td>
		   <td><?php echo $phnumber; ?></td>
		   <td><?php echo $passcode; ?></td>
		   <td>
		     <a href="update.php?email=<?php echo $email;?>">Update</a>&nbsp;||&nbsp;
		     <a href="delete.php?email=<?php echo $email;?>">Delete</a></td>
		 </tr>
	  <?php	
		$i++;}
	  ?>
	  
    </table>
  </body>
</html>