<?php
   
   
   session_start();
   $email = $_SESSION['email'];
   
   if(isset($email))
   {
	   session_destroy();
	   header('location:loginpage.html');
   }
?>