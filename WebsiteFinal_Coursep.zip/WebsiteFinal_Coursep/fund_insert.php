<?php
    // get values from the sign up form with the get method

    $name = $_GET['name'];
    $damnt = $_GET['damnt'];
    $country = $_GET['country'];
    $phnumber = $_GET['phnumber'];
    $address = $_GET['address'];
	$pincode = $_GET['pincode'];
    

// mysqli will connect to database 4 parameter
    $con = mysqli_connect('localhost','root','','admin') or die ("<h1>connection failed</h1>");
    if ($con)
    {
        // inserting values in the table(database)
        $query = "insert into fundraiser values('$name', '$damnt', '$country', $phnumber, '$address','$pincode')";
        $res = mysqli_query($con, $query);

        if($res)
        {
            //echo "<h1>Data inserted...</h1>";
            header("location:payment.html");
        }
        else
        {
            echo "<h1>Data not inserted...</h1>";
        }
    }

?>